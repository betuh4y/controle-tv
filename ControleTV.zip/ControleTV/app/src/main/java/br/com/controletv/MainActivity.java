package br.com.controletv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {

    static final int FUNDO = 0xFF15171C, TECLA = 0xFF2A2E37, ACENTO = 0xFF3B82F6, VERMELHO = 0xFFDC2626, VERDE = 0xFF16A34A;

    private SharedPreferences prefs;
    private TvWifi wifi;
    private TvIr ir;
    private boolean modoIr;
    private TextView status;
    private Button bModo;
    private EditText campoIp;
    private LinearLayout linhaIp;
    private final Handler h = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("tv", MODE_PRIVATE);
        ir = new TvIr(this);
        wifi = new TvWifi(this, (texto, ok) -> h.post(() -> {
            status.setText(texto);
            status.setTextColor(ok ? 0xFF86EFAC : 0xFFCBD5E1);
        }));
        modoIr = prefs.getBoolean("modo_ir", false) && ir.disponivel();

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(FUNDO);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(28), dp(16), dp(24));
        sv.addView(col);
        setContentView(sv);

        TextView t = texto("📺 Controle TV Samsung", 22, true, Color.WHITE);
        col.addView(t);

        // modo + status
        LinearLayout topo = linha();
        bModo = botao("", v -> trocarModo(), TECLA, 14);
        topo.addView(bModo, peso(1));
        col.addView(topo);
        status = texto("", 13, false, 0xFFCBD5E1);
        status.setPadding(0, dp(6), 0, dp(6));
        col.addView(status);

        // IP da TV (modo Wi-Fi)
        linhaIp = linha();
        campoIp = new EditText(this);
        campoIp.setHint("IP da TV (ex.: 192.168.0.15)");
        campoIp.setHintTextColor(0xFF6B7280);
        campoIp.setTextColor(Color.WHITE);
        campoIp.setSingleLine(true);
        campoIp.setInputType(InputType.TYPE_CLASS_PHONE);
        campoIp.setText(wifi.ipSalvo());
        linhaIp.addView(campoIp, peso(1));
        linhaIp.addView(botao("🔍 Procurar", v -> procurar(), TECLA, 13));
        linhaIp.addView(botao("Conectar", v -> wifi.conectar(campoIp.getText().toString()), ACENTO, 13));
        col.addView(linhaIp);

        espaco(col, 12);

        // ===== controle =====
        LinearLayout l1 = linha();
        l1.addView(tecla("⏻", "KEY_POWER", VERMELHO, false), peso(1));
        l1.addView(tecla("🔇", "KEY_MUTE", TECLA, false), peso(1));
        l1.addView(tecla("Fonte", "KEY_SOURCE", TECLA, false), peso(1));
        col.addView(l1);

        LinearLayout l2 = linha();
        l2.addView(tecla("Vol +", "KEY_VOLUP", TECLA, true), peso(1));
        l2.addView(tecla("▲", "KEY_UP", TECLA, true), peso(1));
        l2.addView(tecla("Can +", "KEY_CHUP", TECLA, true), peso(1));
        col.addView(l2);

        LinearLayout l3 = linha();
        l3.addView(tecla("◀", "KEY_LEFT", TECLA, true), peso(1));
        l3.addView(tecla("OK", "KEY_ENTER", ACENTO, false), peso(1));
        l3.addView(tecla("▶", "KEY_RIGHT", TECLA, true), peso(1));
        col.addView(l3);

        LinearLayout l4 = linha();
        l4.addView(tecla("Vol −", "KEY_VOLDOWN", TECLA, true), peso(1));
        l4.addView(tecla("▼", "KEY_DOWN", TECLA, true), peso(1));
        l4.addView(tecla("Can −", "KEY_CHDOWN", TECLA, true), peso(1));
        col.addView(l4);

        LinearLayout l5 = linha();
        l5.addView(tecla("↩ Voltar", "KEY_RETURN", TECLA, false), peso(1));
        l5.addView(tecla("🏠 Início", "KEY_HOME", TECLA, false), peso(1));
        l5.addView(tecla("☰ Menu", "KEY_MENU", TECLA, false), peso(1));
        col.addView(l5);

        LinearLayout l6 = linha();
        l6.addView(tecla("▶ Play", "KEY_PLAY", TECLA, false), peso(1));
        l6.addView(tecla("⏸ Pausa", "KEY_PAUSE", TECLA, false), peso(1));
        l6.addView(tecla("✖ Sair", "KEY_EXIT", TECLA, false), peso(1));
        col.addView(l6);

        espaco(col, 10);
        String[][] nums = {{"1", "2", "3"}, {"4", "5", "6"}, {"7", "8", "9"}, {"ℹ", "0", "🛠"}};
        for (String[] r : nums) {
            LinearLayout ln = linha();
            for (String n : r) {
                String k = n.equals("ℹ") ? "KEY_INFO" : n.equals("🛠") ? "KEY_TOOLS" : "KEY_" + n;
                ln.addView(tecla(n, k, 0xFF1F232B, false), peso(1));
            }
            col.addView(ln);
        }

        espaco(col, 14);
        TextView dica = texto("Dica: segure Vol, Canal e as setas para repetir.\n"
                + "Wi-Fi: Smart TV Samsung 2016+ no mesmo Wi-Fi do celular. Na 1ª vez a TV pergunta se permite — aperte PERMITIR.\n"
                + "Infravermelho: aponte o topo do celular para a TV (só em celulares com infravermelho).", 12, false, 0xFF9CA3AF);
        col.addView(dica);

        atualizarModo();
        if (!modoIr && !wifi.ipSalvo().isEmpty()) wifi.conectar(wifi.ipSalvo());
    }

    @Override protected void onDestroy() { wifi.desconectar(); super.onDestroy(); }

    // ===== modos =====

    private void trocarModo() {
        if (!ir.disponivel()) {
            Toast.makeText(this, "Este celular não tem infravermelho: só dá pelo Wi-Fi", Toast.LENGTH_LONG).show();
            return;
        }
        modoIr = !modoIr;
        prefs.edit().putBoolean("modo_ir", modoIr).apply();
        atualizarModo();
        if (!modoIr && !wifi.conectado()) wifi.conectar(campoIp.getText().toString());
    }

    private void atualizarModo() {
        bModo.setText(modoIr ? "🔴 Modo: Infravermelho  (tocar para Wi-Fi)" : "📶 Modo: Wi-Fi" + (ir.disponivel() ? "  (tocar para Infravermelho)" : ""));
        linhaIp.setVisibility(modoIr ? View.GONE : View.VISIBLE);
        if (modoIr) { status.setText("Aponte o celular para a TV 📡"); status.setTextColor(0xFFFCA5A5); }
    }

    // ===== envio =====

    private void enviar(String k) {
        vibrar();
        if (modoIr) {
            if (!ir.enviar(k)) Toast.makeText(this, "Tecla não disponível no infravermelho", Toast.LENGTH_SHORT).show();
            return;
        }
        if (k.equals("KEY_POWER") && !wifi.conectado()) {
            // TV desligada: tenta ligar pela rede e reconectar
            if (wifi.ligarPelaRede()) {
                status.setText("Ligando a TV pela rede… ⏻");
                h.postDelayed(() -> wifi.conectar(campoIp.getText().toString()), 8000);
            } else {
                status.setText("Para ligar pela rede, conecte com a TV ligada pelo menos uma vez antes.");
            }
            return;
        }
        if (!wifi.enviar(k, "Click")) {
            status.setText("Sem conexão com a TV — toque em Conectar");
            status.setTextColor(0xFFFCA5A5);
        }
    }

    private void procurar() {
        status.setText("🔍 Procurando TVs Samsung no Wi-Fi…");
        new Thread(() -> {
            Map<String, String> achadas = wifi.procurar();
            h.post(() -> {
                if (achadas.isEmpty()) {
                    status.setText("Não achei nenhuma TV. Ela está ligada e no mesmo Wi-Fi? Dá para digitar o IP (na TV: Configurações → Geral → Rede → Status da rede).");
                    return;
                }
                List<String> ips = new ArrayList<>(achadas.keySet());
                String[] nomes = new String[ips.size()];
                for (int i = 0; i < nomes.length; i++) nomes[i] = achadas.get(ips.get(i)) + "\n" + ips.get(i);
                new AlertDialog.Builder(this).setTitle("TVs encontradas")
                        .setItems(nomes, (d, i) -> { campoIp.setText(ips.get(i)); wifi.conectar(ips.get(i)); })
                        .show();
            });
        }).start();
    }

    // ===== visual =====

    private View tecla(String rotulo, String k, int cor, boolean repete) {
        Button b = botao(rotulo, null, cor, rotulo.length() <= 2 ? 22 : 15);
        b.setMinHeight(dp(58));
        if (!repete) { b.setOnClickListener(v -> enviar(k)); return b; }
        // segurar = repetir
        final Runnable[] rep = new Runnable[1];
        rep[0] = () -> { enviar(k); h.postDelayed(rep[0], 180); };
        b.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) { v.setPressed(true); enviar(k); h.postDelayed(rep[0], 450); }
            else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) { v.setPressed(false); h.removeCallbacks(rep[0]); }
            return true;
        });
        return b;
    }

    private Button botao(String t, View.OnClickListener l, int cor, int sp) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        GradientDrawable g = new GradientDrawable();
        g.setColor(cor);
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        if (l != null) b.setOnClickListener(l);
        return b;
    }

    private LinearLayout linha() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setPadding(0, dp(4), 0, dp(4));
        return l;
    }

    private LinearLayout.LayoutParams peso(float w) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, w);
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    private TextView texto(String s, int sp, boolean negrito, int cor) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(cor);
        if (negrito) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void espaco(LinearLayout col, int d) {
        View v = new View(this);
        col.addView(v, new LinearLayout.LayoutParams(1, dp(d)));
    }

    private void vibrar() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(18, 120)); else v.vibrate(18);
        } catch (Exception ignored) { }
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
