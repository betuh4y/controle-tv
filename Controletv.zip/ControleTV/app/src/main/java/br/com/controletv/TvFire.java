package br.com.controletv;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import dadb.AdbKeyPair;
import dadb.Dadb;

/**
 * Controle do FIRE TV STICK (e outros aparelhos Android TV) pelo Wi-Fi, usando a Depuração ADB.
 * No Fire TV: Configurações → Meu Fire TV → Opções do desenvolvedor → Depuração ADB = ATIVADO.
 * Na 1ª conexão o Fire TV pergunta "Permitir depuração?" → marque "Sempre permitir" e OK.
 */
public class TvFire {

    private final Context ctx;
    private final SharedPreferences prefs;
    private final TvWifi.Ouvinte ouvinte;
    private final ExecutorService fila = Executors.newSingleThreadExecutor();
    private Dadb adb;
    private String ip = "";
    private volatile boolean conectado = false;

    /** Teclas do controle (nomes da Samsung) → códigos de tecla do Android. */
    static final Map<String, Integer> COD = new HashMap<>();
    static {
        COD.put("KEY_POWER", 26); COD.put("KEY_MUTE", 164); COD.put("KEY_SOURCE", 178);
        COD.put("KEY_VOLUP", 24); COD.put("KEY_VOLDOWN", 25); COD.put("KEY_CHUP", 166); COD.put("KEY_CHDOWN", 167);
        COD.put("KEY_UP", 19); COD.put("KEY_DOWN", 20); COD.put("KEY_LEFT", 21); COD.put("KEY_RIGHT", 22);
        COD.put("KEY_ENTER", 23); COD.put("KEY_RETURN", 4); COD.put("KEY_HOME", 3); COD.put("KEY_EXIT", 3);
        COD.put("KEY_MENU", 82); COD.put("KEY_PLAY", 85); COD.put("KEY_PAUSE", 85);
        COD.put("KEY_INFO", 165); COD.put("KEY_TOOLS", 176);
        for (int n = 0; n <= 9; n++) COD.put("KEY_" + n, 7 + n);
    }

    TvFire(Context c, TvWifi.Ouvinte o) {
        ctx = c.getApplicationContext();
        prefs = c.getSharedPreferences("tv", Context.MODE_PRIVATE);
        ouvinte = o;
    }

    boolean conectado() { return conectado; }

    void conectar(String ipTv) {
        ip = ipTv.trim();
        if (ip.isEmpty()) { ouvinte.estado("Digite o IP do Fire TV ou toque em 🔍 Procurar", false); return; }
        prefs.edit().putString("ip", ip).apply();
        ouvinte.estado("🔥 Conectando no Fire TV " + ip + "… olhe a TV: se pedir, marque \"Sempre permitir\" e OK", false);
        fila.execute(() -> {
            fechar();
            try {
                File priv = new File(ctx.getFilesDir(), "adbkey"), pub = new File(ctx.getFilesDir(), "adbkey.pub");
                if (!priv.exists() || !pub.exists()) AdbKeyPair.Companion.generate(priv, pub);
                AdbKeyPair chave = AdbKeyPair.Companion.read(priv, pub);
                adb = Dadb.Companion.create(ip, 5555, chave);
                adb.shell("echo ok");               // abre a conexão (é aqui que o Fire TV pede permissão)
                conectado = true;
                ouvinte.estado("✅ Conectado ao Fire TV " + ip, true);
            } catch (Throwable t) {
                conectado = false;
                ouvinte.estado("❌ Não conectou no Fire TV " + ip + ". Ative a Depuração ADB (Configurações → Meu Fire TV → "
                        + "Opções do desenvolvedor) e aceite o pedido na TV.", false);
            }
        });
    }

    boolean enviar(String tecla) {
        Integer k = COD.get(tecla);
        if (k == null) return false;
        if (adb == null || !conectado) return false;
        fila.execute(() -> {
            try { adb.shell("input keyevent " + k); }
            catch (Throwable t) {
                conectado = false;
                ouvinte.estado("Conexão com o Fire TV caiu — toque em Conectar", false);
            }
        });
        return true;
    }

    private void fechar() {
        if (adb != null) { try { adb.close(); } catch (Throwable ignored) { } }
        adb = null;
        conectado = false;
    }

    void desconectar() { fila.execute(this::fechar); }
}
