package br.com.controletv;

import android.content.Context;
import android.hardware.ConsumerIrManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Controle pelo INFRAVERMELHO do celular (para celulares com "olhinho" de controle, como muitos Xiaomi/Redmi).
 * Usa o protocolo Samsung (32 bits, 38 kHz) — funciona com qualquer TV Samsung, até as que não são smart.
 */
public class TvIr {

    private final ConsumerIrManager ir;

    /** Código Samsung de cada tecla (endereço 0x07 0x07 + comando). */
    static final Map<String, Integer> COD = new HashMap<>();
    static {
        COD.put("KEY_POWER", 0x02); COD.put("KEY_SOURCE", 0x01); COD.put("KEY_MUTE", 0x0F);
        COD.put("KEY_VOLUP", 0x07); COD.put("KEY_VOLDOWN", 0x0B);
        COD.put("KEY_CHUP", 0x12); COD.put("KEY_CHDOWN", 0x10);
        COD.put("KEY_UP", 0x60); COD.put("KEY_DOWN", 0x61); COD.put("KEY_LEFT", 0x65); COD.put("KEY_RIGHT", 0x62);
        COD.put("KEY_ENTER", 0x68); COD.put("KEY_RETURN", 0x58); COD.put("KEY_EXIT", 0x2D);
        COD.put("KEY_HOME", 0x79); COD.put("KEY_MENU", 0x1A); COD.put("KEY_INFO", 0x1F); COD.put("KEY_TOOLS", 0x4B);
        COD.put("KEY_PLAY", 0x47); COD.put("KEY_PAUSE", 0x4A);
        COD.put("KEY_1", 0x04); COD.put("KEY_2", 0x05); COD.put("KEY_3", 0x06); COD.put("KEY_4", 0x08);
        COD.put("KEY_5", 0x09); COD.put("KEY_6", 0x0A); COD.put("KEY_7", 0x0C); COD.put("KEY_8", 0x0D);
        COD.put("KEY_9", 0x0E); COD.put("KEY_0", 0x11);
    }

    TvIr(Context c) {
        ConsumerIrManager m = null;
        try { m = (ConsumerIrManager) c.getSystemService(Context.CONSUMER_IR_SERVICE); } catch (Exception ignored) { }
        ir = m;
    }

    boolean disponivel() {
        try { return ir != null && ir.hasIrEmitter(); } catch (Exception e) { return false; }
    }

    /** Envia a tecla. Retorna false se não houver código para ela ou se o celular não tiver infravermelho. */
    boolean enviar(String tecla) {
        Integer cmd = COD.get(tecla);
        if (cmd == null || !disponivel()) return false;
        try { ir.transmit(38000, padrao(0x07, cmd)); return true; } catch (Exception e) { return false; }
    }

    /** Monta o sinal Samsung32 em microssegundos: cabeçalho, endereço 2x, comando e comando invertido. */
    static int[] padrao(int endereco, int comando) {
        List<Integer> p = new ArrayList<>();
        p.add(4500); p.add(4500);
        int[] bytes = {endereco & 0xFF, endereco & 0xFF, comando & 0xFF, (~comando) & 0xFF};
        for (int b : bytes) {
            for (int i = 0; i < 8; i++) {           // bit menos significativo primeiro
                p.add(560);
                p.add(((b >> i) & 1) == 1 ? 1690 : 560);
            }
        }
        p.add(560);                                  // pulso final
        int[] out = new int[p.size()];
        for (int i = 0; i < out.length; i++) out[i] = p.get(i);
        return out;
    }
}
