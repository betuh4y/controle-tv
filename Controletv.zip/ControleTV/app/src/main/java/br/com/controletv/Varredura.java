package br.com.controletv;

import android.content.Context;
import android.net.wifi.WifiManager;

import org.json.JSONObject;

import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Varre o Wi-Fi atrás de TVs e aparelhos de TV:
 *  1) pergunta na rede "quem é aparelho de mídia?" (SSDP/DIAL) — pega o nome que o aparelho anuncia;
 *  2) testa cada endereço da rede nas portas usadas por cada marca.
 */
public class Varredura {

    interface Progresso { void andou(int feito, int total); }

    public static class Disp {
        public String ip, nome = "", fabricante = "", modelo = "", tipo = "outro";
        public final List<Integer> portas = new ArrayList<>();
        Disp(String ip) { this.ip = ip; }

        public boolean controlavel() { return tipo.equals("samsung") || tipo.equals("fire"); }

        public String rotulo() {
            String ico = tipo.equals("samsung") ? "📺 TV Samsung" : tipo.equals("fire") ? "🔥 Fire TV"
                    : tipo.equals("chromecast") ? "📡 Chromecast / Google TV" : tipo.equals("roku") ? "🟣 Roku"
                    : tipo.equals("lg") ? "📺 TV LG" : tipo.equals("philips") ? "📺 TV Philips" : "❔ Aparelho de mídia";
            String n = !nome.isEmpty() ? nome : (!modelo.isEmpty() ? modelo : "");
            String extra = tipo.equals("fire") && !portas.contains(5555) ? "\n⚠️ ative a Depuração ADB para controlar" : "";
            String nao = !controlavel() ? "  (ainda não controlável)" : "";
            return ico + (n.isEmpty() ? "" : " — " + n) + nao + "\n" + ip + extra;
        }
    }

    // porta → tipo de aparelho
    private static final int[] PORTAS = {8001, 5555, 8008, 8060, 3000, 1925};

    private final Context ctx;
    Varredura(Context c) { ctx = c.getApplicationContext(); }

    public List<Disp> procurar(Progresso prog) {
        Map<String, Disp> achados = new ConcurrentHashMap<>();
        // 1) anúncios na rede (em paralelo com a varredura de portas)
        Thread ssdp = new Thread(() -> ssdp(achados));
        ssdp.start();

        // 2) varredura de portas na sub-rede
        String base = baseDaRede();
        if (base != null) {
            ExecutorService pool = Executors.newFixedThreadPool(64);
            int total = 254 * PORTAS.length;
            AtomicInteger feito = new AtomicInteger();
            for (int h = 1; h <= 254; h++) {
                final String ip = base + h;
                for (int porta : PORTAS) {
                    pool.execute(() -> {
                        if (aberta(ip, porta, 350)) {
                            Disp d = achados.computeIfAbsent(ip, Disp::new);
                            synchronized (d) { if (!d.portas.contains(porta)) d.portas.add(porta); }
                        }
                        int f = feito.incrementAndGet();
                        if (prog != null && f % 60 == 0) prog.andou(f, total);
                    });
                }
            }
            pool.shutdown();
            try { pool.awaitTermination(25, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
        }
        try { ssdp.join(6000); } catch (InterruptedException ignored) { }

        // 3) identifica cada um
        List<Disp> lista = new ArrayList<>();
        for (Disp d : achados.values()) {
            classificar(d);
            if (!d.tipo.equals("outro") || !d.nome.isEmpty()) lista.add(d);
        }
        Collections.sort(lista, (a, b) -> Boolean.compare(b.controlavel(), a.controlavel()));
        return lista;
    }

    private void classificar(Disp d) {
        String f = (d.fabricante + " " + d.modelo + " " + d.nome).toLowerCase();
        if (d.portas.contains(8001) || f.contains("samsung")) {
            d.tipo = "samsung";
            try {
                JSONObject dev = new JSONObject(get("http://" + d.ip + ":8001/api/v2/", 1500)).optJSONObject("device");
                if (dev != null) { d.nome = dev.optString("name", d.nome); d.modelo = dev.optString("modelName", d.modelo); }
            } catch (Exception ignored) { }
        } else if (f.contains("amazon") || f.contains("fire") || f.matches(".*\\baft[a-z0-9]*.*")) d.tipo = "fire";
        else if (d.portas.contains(5555)) d.tipo = "fire";          // ADB aberto: Fire TV / Android TV
        else if (d.portas.contains(8008) || f.contains("google") || f.contains("chromecast")) d.tipo = "chromecast";
        else if (d.portas.contains(8060) || f.contains("roku")) d.tipo = "roku";
        else if (d.portas.contains(3000) || f.contains("lg ") || f.contains("webos")) d.tipo = "lg";
        else if (d.portas.contains(1925) || f.contains("philips")) d.tipo = "philips";
    }

    /** SSDP: pede para os aparelhos de mídia se anunciarem e lê nome/fabricante/modelo. */
    private void ssdp(Map<String, Disp> achados) {
        WifiManager.MulticastLock lock = null;
        try {
            WifiManager w = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            lock = w.createMulticastLock("varredura");
            lock.acquire();
            DatagramSocket s = new DatagramSocket();
            s.setSoTimeout(700);
            for (String st : new String[]{"ssdp:all", "urn:dial-multiscreen-org:service:dial:1",
                    "urn:samsung.com:device:RemoteControlReceiver:1", "urn:schemas-upnp-org:device:MediaRenderer:1"}) {
                String m = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: " + st + "\r\n\r\n";
                byte[] b = m.getBytes(StandardCharsets.US_ASCII);
                s.send(new DatagramPacket(b, b.length, InetAddress.getByName("239.255.255.250"), 1900));
            }
            Map<String, String> locais = new ConcurrentHashMap<>();
            Pattern loc = Pattern.compile("(?i)LOCATION:\\s*(http://([0-9.]+)[^\\s]*)");
            long fim = System.currentTimeMillis() + 4000;
            byte[] buf = new byte[4096];
            while (System.currentTimeMillis() < fim) {
                try {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    s.receive(p);
                    String r = new String(p.getData(), 0, p.getLength(), StandardCharsets.US_ASCII);
                    Matcher mm = loc.matcher(r);
                    if (mm.find() && !locais.containsKey(mm.group(2))) locais.put(mm.group(2), mm.group(1));
                } catch (SocketTimeoutException ignored) { }
            }
            s.close();
            for (Map.Entry<String, String> e : locais.entrySet()) {
                try {
                    String xml = get(e.getValue(), 1500);
                    Disp d = achados.computeIfAbsent(e.getKey(), Disp::new);
                    if (d.nome.isEmpty()) d.nome = tag(xml, "friendlyName");
                    if (d.fabricante.isEmpty()) d.fabricante = tag(xml, "manufacturer");
                    if (d.modelo.isEmpty()) d.modelo = tag(xml, "modelName");
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) {
        } finally {
            if (lock != null) try { lock.release(); } catch (Exception ignored) { }
        }
    }

    private static String tag(String xml, String t) {
        Matcher m = Pattern.compile("<" + t + ">([^<]*)</" + t + ">").matcher(xml);
        return m.find() ? m.group(1).trim() : "";
    }

    private static boolean aberta(String ip, int porta, int ms) {
        try (Socket s = new Socket()) { s.connect(new InetSocketAddress(ip, porta), ms); return true; }
        catch (Exception e) { return false; }
    }

    private static String get(String url, int ms) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(ms); c.setReadTimeout(ms);
        try (InputStream in = c.getInputStream(); Scanner sc = new Scanner(in, "UTF-8").useDelimiter("\\A")) {
            return sc.hasNext() ? sc.next() : "";
        } finally { c.disconnect(); }
    }

    /** "192.168.0." a partir do IP do celular no Wi-Fi. */
    private String baseDaRede() {
        try {
            WifiManager w = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            int ip = w.getConnectionInfo().getIpAddress();
            if (ip == 0) return null;
            return (ip & 0xFF) + "." + ((ip >> 8) & 0xFF) + "." + ((ip >> 16) & 0xFF) + ".";
        } catch (Exception e) { return null; }
    }
}
