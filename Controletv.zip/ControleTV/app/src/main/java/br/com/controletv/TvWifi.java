package br.com.controletv;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.util.Base64;

import org.json.JSONObject;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/**
 * Controle pelo Wi-Fi das Smart TVs Samsung (2016 em diante, Tizen).
 * Conecta no "canal de controle remoto" da TV; na primeira vez a TV pergunta se permite o "Controle TV".
 */
public class TvWifi {

    interface Ouvinte { void estado(String texto, boolean conectado); }

    private final Context ctx;
    private final SharedPreferences prefs;
    private final Ouvinte ouvinte;
    private final OkHttpClient http;
    private WebSocket ws;
    private boolean conectado = false;
    private boolean tentouAntigo = false;
    private String ip = "";

    TvWifi(Context c, Ouvinte o) {
        ctx = c.getApplicationContext();
        prefs = c.getSharedPreferences("tv", Context.MODE_PRIVATE);
        ouvinte = o;
        http = clienteQueAceitaATv();
    }

    boolean conectado() { return conectado; }

    /** A TV usa certificado próprio (não é de site): aceitamos, só para falar com ela na rede de casa. */
    private static OkHttpClient clienteQueAceitaATv() {
        try {
            X509TrustManager tm = new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] c, String a) { }
                public void checkServerTrusted(X509Certificate[] c, String a) { }
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            };
            SSLContext ssl = SSLContext.getInstance("TLS");
            ssl.init(null, new TrustManager[]{tm}, new SecureRandom());
            return new OkHttpClient.Builder()
                    .sslSocketFactory(ssl.getSocketFactory(), tm)
                    .hostnameVerifier((h, s) -> true)
                    .connectTimeout(5, TimeUnit.SECONDS)
                    .readTimeout(0, TimeUnit.SECONDS)
                    .pingInterval(20, TimeUnit.SECONDS)
                    .build();
        } catch (Exception e) {
            return new OkHttpClient();
        }
    }

    void conectar(String ipTv) {
        desconectar();
        ip = ipTv.trim();
        tentouAntigo = false;
        if (ip.isEmpty()) { ouvinte.estado("Digite o IP da TV ou toque em 🔍 Procurar", false); return; }
        prefs.edit().putString("ip", ip).apply();
        ouvinte.estado("Conectando em " + ip + "… (se a TV perguntar, aperte PERMITIR)", false);
        abrir(true);
        // Descobre o MAC da TV para poder LIGÁ-LA pela rede depois
        new Thread(this::buscarMac).start();
    }

    private void abrir(boolean seguro) {
        String nome = Base64.encodeToString("Controle TV".getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        String token = prefs.getString("token_" + ip, "");
        String url = seguro
                ? "wss://" + ip + ":8002/api/v2/channels/samsung.remote.control?name=" + nome + (token.isEmpty() ? "" : "&token=" + token)
                : "ws://" + ip + ":8001/api/v2/channels/samsung.remote.control?name=" + nome;
        ws = http.newWebSocket(new Request.Builder().url(url).build(), new WebSocketListener() {
            @Override public void onMessage(WebSocket w, String texto) {
                try {
                    JSONObject j = new JSONObject(texto);
                    String ev = j.optString("event");
                    if ("ms.channel.connect".equals(ev)) {
                        JSONObject d = j.optJSONObject("data");
                        if (d != null && d.has("token")) prefs.edit().putString("token_" + ip, d.optString("token")).apply();
                        conectado = true;
                        ouvinte.estado("✅ Conectado à TV " + ip, true);
                    } else if ("ms.channel.unauthorized".equals(ev)) {
                        conectado = false;
                        ouvinte.estado("❌ A TV recusou. Na TV: Configurações → Geral → Gerenciador de dispositivos externos → permita o \"Controle TV\"", false);
                    }
                } catch (Exception ignored) { }
            }
            @Override public void onFailure(WebSocket w, Throwable t, Response r) {
                conectado = false;
                if (seguro && !tentouAntigo) { tentouAntigo = true; abrir(false); return; } // TVs 2016–2017
                ouvinte.estado("❌ Não achei a TV em " + ip + ". Ela está ligada e no mesmo Wi-Fi?", false);
            }
            @Override public void onClosed(WebSocket w, int c, String m) {
                conectado = false;
                ouvinte.estado("Desconectado da TV", false);
            }
        });
    }

    void desconectar() {
        if (ws != null) { try { ws.close(1000, "tchau"); } catch (Exception ignored) { } }
        ws = null;
        conectado = false;
    }

    /** Envia uma tecla (KEY_VOLUP, KEY_POWER, ...). Para segurar, use "Press" e depois "Release". */
    boolean enviar(String tecla, String modo) {
        if (ws == null || !conectado) return false;
        try {
            JSONObject p = new JSONObject()
                    .put("Cmd", modo == null ? "Click" : modo)
                    .put("DataOfCmd", tecla)
                    .put("Option", "false")
                    .put("TypeOfRemote", "SendRemoteKey");
            return ws.send(new JSONObject().put("method", "ms.remote.control").put("params", p).toString());
        } catch (Exception e) { return false; }
    }

    /** Liga a TV desligada pela rede (Wake-on-LAN). Precisa ter conectado pelo menos uma vez antes. */
    boolean ligarPelaRede() {
        final String mac = prefs.getString("mac", "");
        if (mac.isEmpty()) return false;
        new Thread(() -> {
            try {
                byte[] m = new byte[6];
                String[] h = mac.split("[:-]");
                for (int i = 0; i < 6; i++) m[i] = (byte) Integer.parseInt(h[i], 16);
                byte[] pacote = new byte[6 + 16 * 6];
                for (int i = 0; i < 6; i++) pacote[i] = (byte) 0xFF;
                for (int i = 6; i < pacote.length; i += 6) System.arraycopy(m, 0, pacote, i, 6);
                DatagramSocket s = new DatagramSocket();
                s.setBroadcast(true);
                for (String destino : new String[]{"255.255.255.255", broadcastDaRede()}) {
                    if (destino == null) continue;
                    for (int porta : new int[]{9, 7}) {
                        s.send(new DatagramPacket(pacote, pacote.length, InetAddress.getByName(destino), porta));
                    }
                }
                s.close();
            } catch (Exception ignored) { }
        }).start();
        return true;
    }

    private void buscarMac() {
        try (Response r = http.newCall(new Request.Builder().url("http://" + ip + ":8001/api/v2/").build()).execute()) {
            JSONObject d = new JSONObject(r.body().string()).optJSONObject("device");
            if (d == null) return;
            String mac = d.optString("wifiMac", "");
            if (!mac.isEmpty()) prefs.edit().putString("mac", mac).putString("nome", d.optString("name", "TV")).apply();
        } catch (Exception ignored) { }
    }

    private String broadcastDaRede() {
        try {
            WifiManager w = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            int ipW = w.getDhcpInfo().ipAddress, mask = w.getDhcpInfo().netmask;
            if (ipW == 0 || mask == 0) return null;
            int b = (ipW & mask) | ~mask;
            return (b & 0xFF) + "." + ((b >> 8) & 0xFF) + "." + ((b >> 16) & 0xFF) + "." + ((b >> 24) & 0xFF);
        } catch (Exception e) { return null; }
    }

    /** Procura TVs Samsung na rede de casa (SSDP). Roda em segundo plano; devolve IP → nome. */
    Map<String, String> procurar() {
        Map<String, String> achadas = new LinkedHashMap<>();
        WifiManager.MulticastLock lock = null;
        try {
            WifiManager w = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            lock = w.createMulticastLock("controletv");
            lock.acquire();
            DatagramSocket s = new DatagramSocket();
            s.setSoTimeout(800);
            String[] tipos = {"urn:samsung.com:device:RemoteControlReceiver:1", "urn:dial-multiscreen-org:service:dial:1"};
            for (String st : tipos) {
                String msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: " + st + "\r\n\r\n";
                byte[] b = msg.getBytes(StandardCharsets.US_ASCII);
                s.send(new DatagramPacket(b, b.length, InetAddress.getByName("239.255.255.250"), 1900));
            }
            List<String> ips = new ArrayList<>();
            long fim = System.currentTimeMillis() + 3500;
            byte[] buf = new byte[2048];
            Pattern loc = Pattern.compile("(?i)LOCATION:\\s*http://([0-9.]+):");
            while (System.currentTimeMillis() < fim) {
                try {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    s.receive(p);
                    String r = new String(p.getData(), 0, p.getLength(), StandardCharsets.US_ASCII);
                    Matcher m = loc.matcher(r);
                    String ipAchado = m.find() ? m.group(1) : p.getAddress().getHostAddress();
                    if (!ips.contains(ipAchado)) ips.add(ipAchado);
                } catch (SocketTimeoutException ignored) { }
            }
            s.close();
            // Confirma quais são TVs Samsung perguntando o nome a cada uma
            for (String i : ips) {
                try (Response r = http.newCall(new Request.Builder().url("http://" + i + ":8001/api/v2/").build()).execute()) {
                    JSONObject d = new JSONObject(r.body().string()).optJSONObject("device");
                    if (d != null) achadas.put(i, d.optString("name", "TV Samsung") + " (" + d.optString("modelName", "") + ")");
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) {
        } finally {
            if (lock != null) try { lock.release(); } catch (Exception ignored) { }
        }
        return achadas;
    }

    String ipSalvo() { return prefs.getString("ip", ""); }
}
